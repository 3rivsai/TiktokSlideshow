"""
video structure needs to be a bit different.
because we need to be able to add both videos and images together
so we can do the same thing as before, with product, content type, caption, but then also some
other word for content type like content container? or so? and that can be image or video.

need to be able to add voiceover/music to it
video length in settings as well or have default length.
renderer needs to be much better.

instead of captions needs to have type of content there
video format fixer.

"""
